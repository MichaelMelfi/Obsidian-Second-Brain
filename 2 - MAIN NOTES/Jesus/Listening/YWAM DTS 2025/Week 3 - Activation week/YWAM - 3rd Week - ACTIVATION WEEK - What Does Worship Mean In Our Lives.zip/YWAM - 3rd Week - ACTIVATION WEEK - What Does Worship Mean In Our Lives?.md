2025-01-24 09:46

Status: #FListening 

Tags: [[Christian]] [[3 - TAGS/YWAM]] [[Teaching]] [[Worship]] [[Praise]] [[David]] [[Psalms]] [[John]] [[Matthew]] [[Psalms 107]] [[John 4]] [[Matthew 4]] 

# YWAM - 3rd Week - ACTIVATION WEEK - What Does Worship Mean In Our Lives

Worship is very different to Praise ([[Biblical Ways to Praise]])
Worship is Submission and Surrender to God

### What Does Worship Mean To Me?
- Openness
- Connection to God
- Putting God Back On Top/Centre Of My Life
- Asking God What Do You Want From Me?
- Putting Myself Down And God Up
- Worship is like a road that we walk down to get to where God is.
- Freedom From Everything Around Me

## Why Do I Worship?
- For Him Saving My Life In The Physical and Spiritual
- For Him Keeping Me On The Straight And Narrow
- For His Guidance
- For His Mercy
- For His grace
- For His Sacrifice On The Cross
- For The Miracle Of Healing Over My Body
- For My Family’s Lives
- For The Trials That Made Me a Stronger Man Of God

We want our lives to be hungering and thirsting after the Lord **ALWAYS**.

> “For he satisfies the thirsty and fills the hungry with good things.”
‭‭==Psalms‬ ‭107‬:‭9‬ ‭NLT‬‬==
https://bible.com/bible/116/psa.107.9.NLT

Knowing the truth (The Word Of God) brings transformation in our lives.

Once God is Centre in your life, you have a confidence and a peace.

## How To Worship
1. Singing
- Singing is like a road that we walk down to get to where God is.

2. Building something to glorify God
- For Example Angkor Watt, the people who built the temple were normal people (A lot of them lost their lives) who wanted to build something to worship their God
- What are we building in our own lives to make it easier to worship and step into a place and posture of worship?
- We are the temple of the Holy Spirit, We are now the tabernacle of the Lord, Our body should be built to be a place of worship for God.

If you have a posture of worship, it does not matter the song or the sound system or the band because worship comes from you and not the environment you are in.

### King David
He was a worshiper, whatever he did he worshiped and praised.
While he was in failure, he praised and worshipped.
No matter the circumstance or surrounding he was constantly in a posture or **Praise** and **Worship**.


> “But the time is coming—indeed it’s here now—when true worshipers will worship the Father in spirit and in truth. The Father is looking for those who will worship him that way. For God is Spirit, so those who worship him must worship in spirit and in truth.””
‭‭==John‬ ‭4‬:‭23‬-‭24‬ ‭NLT‬‬==
https://bible.com/bible/116/jhn.4.24.NLT

> ““I will give it all to you,” he said, “if you will kneel down and worship me.” “Get out of here, Satan,” Jesus told him. “For the Scriptures say, ‘You must worship the Lord your God and serve only him.’ ””
‭‭==Matthew‬ ‭4‬:‭9‬-‭10‬ ‭NLT‬‬==
https://bible.com/bible/116/mat.4.9-10.NLT


## Reference

[[Biblical Ways to Praise]]